#
# TABLE STRUCTURE FOR: activity_logs
#

DROP TABLE IF EXISTS `activity_logs`;

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `activity_id` int(11) NOT NULL,
  `activity` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=latin1;

INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('20', '', '0', ' patient created', '2019-11-20 20:20:52');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('21', '', '0', 'Gas Tank equipment created', '2019-11-20 20:32:10');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('22', '', '0', 'Grant Ward', '2019-11-20 20:35:00');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('23', '', '0', 'Gas Tank', '2019-11-20 20:35:17');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('24', '', '0', 'Louis Lane', '2019-11-21 10:58:57');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('25', '', '0', 'Robby spike', '2019-11-21 11:00:39');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('26', '', '0', 'scissor', '2019-11-21 11:23:41');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('27', '', '0', 'scissor', '2019-11-22 18:42:30');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('28', '', '0', 'globe bills', '2019-11-22 23:50:34');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('29', '', '0', 'globe bills', '2019-11-22 23:50:44');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('30', '', '0', 'Face Masks', '2019-11-22 23:51:10');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('31', '', '0', 'Face Masks', '2019-11-22 23:56:48');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('32', '', '0', 'Grant Ward', '2019-11-23 00:18:22');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('33', '', '0', 'Grant Ward', '2019-11-23 00:19:33');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('34', '', '0', 'Skin Color', '2019-11-23 19:11:28');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('35', '', '0', 'Skin Color', '2019-11-23 19:17:01');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('36', '', '0', 'Skin Color', '2019-11-23 19:17:49');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('37', '', '0', 'medical history', '2019-11-23 19:31:12');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('38', '', '0', 'medical history', '2019-11-23 19:32:48');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('39', '', '0', 'meddddd', '2019-11-23 19:36:46');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('40', '', '0', 'medical history', '2019-11-23 19:38:54');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('41', '', '0', 'medical history', '2019-11-23 19:42:44');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('42', '', '0', 'medical history', '2019-11-23 20:47:03');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('43', '', '0', 'medical history', '2019-11-23 20:47:57');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('44', '', '0', 'medical history', '2019-11-23 20:48:16');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('45', '', '0', 'medical history', '2019-11-24 11:49:07');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('46', '', '0', 'medical history', '2019-11-24 12:11:51');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('47', '', '0', 'medical history', '2019-11-24 12:20:55');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('48', '', '0', 'medical history', '2019-11-24 12:23:13');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('49', '', '0', 'medical history', '2019-11-24 12:24:20');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('50', '', '0', 'medical history', '2019-11-24 12:29:08');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('51', '', '0', 'medical history', '2019-11-24 12:30:20');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('52', '', '0', 'medical history', '2019-11-24 13:17:09');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('53', '', '0', 'medical history', '2019-11-24 13:29:58');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('54', '', '0', 'medical history', '2019-11-24 13:30:10');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('55', '', '0', 'medical history', '2019-11-24 13:30:20');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('56', '', '0', 'medical history', '2019-11-24 13:39:24');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('57', '', '0', 'medical history', '2019-11-24 13:39:36');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('58', '', '0', 'medical history', '2019-11-24 13:39:45');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('59', '', '0', 'medical history', '2019-11-24 13:46:35');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('60', '', '0', 'medical history', '2019-11-24 13:46:44');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('61', '', '0', 'medical history', '2019-11-24 13:50:28');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('62', '', '0', 'medical history', '2019-11-24 13:56:12');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('63', '', '0', 'medical history', '2019-11-24 13:56:47');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('64', '', '0', 'medical history', '2019-11-24 13:56:55');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('65', '', '0', 'medical history', '2019-11-24 13:59:36');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('66', '', '0', 'medical history', '2019-11-24 14:00:45');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('67', '', '0', 'medical history', '2019-11-24 14:02:11');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('68', '', '0', 'medical history', '2019-11-24 14:02:57');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('69', '', '0', 'medical history', '2019-11-24 14:42:03');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('70', '', '0', 'medical history', '2019-11-24 14:46:13');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('71', '', '0', 'other', '2019-11-24 16:33:47');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('72', '', '0', 'tacloban', '2019-11-24 16:35:53');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('73', '', '0', 'tacloban', '2019-11-24 16:38:14');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('74', '', '0', 'tacloban', '2019-11-24 16:44:34');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('75', '', '0', 'tacloban', '2019-11-24 16:49:22');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('76', '', '0', 'tacloban', '2019-11-24 16:51:40');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('77', '', '0', 'other', '2019-11-24 16:55:02');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('78', '', '0', 'tacloban', '2019-11-24 16:56:01');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('79', '', '0', 'tacloban', '2019-11-24 16:56:21');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('80', '', '0', 'tacloban', '2019-11-24 16:58:18');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('81', '', '0', 'tacloban', '2019-11-24 17:02:46');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('82', '', '0', 'other', '2019-11-24 17:10:24');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('83', '', '0', 'palo', '2019-11-24 18:08:20');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('84', '', '0', 'carigara', '2019-11-24 18:08:55');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('85', '', '0', 'carigara', '2019-11-24 18:10:15');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('86', '', '0', 'medical history', '2019-11-24 18:12:14');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('87', '', '0', 'other', '2019-11-24 18:15:04');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('88', '', '0', 'othersss', '2019-11-24 18:17:28');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('89', '', '0', '', '2019-11-24 18:18:27');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('90', '', '0', 'medical history', '2019-11-24 18:19:30');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('91', '', '0', 'taee', '2019-11-24 18:21:29');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('92', '', '0', 'aaaa', '2019-11-24 18:22:09');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('93', '', '0', 'gaga', '2019-11-24 18:36:20');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('94', '', '0', 'namee', '2019-11-24 18:39:56');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('95', '', '0', 'sample', '2019-11-24 18:43:49');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('96', '', '0', 'sample', '2019-11-24 19:33:07');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('97', '', '0', 'sample', '2019-11-24 19:35:20');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES ('98', '', '0', 'sample', '2019-11-24 19:36:39');


#
# TABLE STRUCTURE FOR: chat
#

DROP TABLE IF EXISTS `chat`;

CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: equipments
#

DROP TABLE IF EXISTS `equipments`;

CREATE TABLE `equipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT 'activated',
  `date` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `equipment_type` varchar(255) NOT NULL,
  `maintenanceCode` varchar(255) NOT NULL,
  `maintenancePerformed` varchar(255) NOT NULL,
  `maintenanceFrequency` varchar(255) NOT NULL,
  `previousMaintenance` varchar(255) NOT NULL,
  `nextMaintenance` varchar(255) NOT NULL,
  `archive` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `equipments` (`id`, `status`, `date`, `model`, `quantity`, `equipment_type`, `maintenanceCode`, `maintenancePerformed`, `maintenanceFrequency`, `previousMaintenance`, `nextMaintenance`, `archive`, `date_created`) VALUES ('24', 'activated', '5/1/19', 'Face Masks', '2', 'Face Mask', '45456456', 'Clean', '1', '5/5/19', '7/5/19', NULL, '2019-11-20 20:26:09');
INSERT INTO `equipments` (`id`, `status`, `date`, `model`, `quantity`, `equipment_type`, `maintenanceCode`, `maintenancePerformed`, `maintenanceFrequency`, `previousMaintenance`, `nextMaintenance`, `archive`, `date_created`) VALUES ('25', 'activated', '2/7/19', 'Gas Tank', '', 'Gas Tanks', '5676776', 'Clean', '1', '8/4/19', '9/1/19', NULL, '2019-11-20 20:28:32');
INSERT INTO `equipments` (`id`, `status`, `date`, `model`, `quantity`, `equipment_type`, `maintenanceCode`, `maintenancePerformed`, `maintenanceFrequency`, `previousMaintenance`, `nextMaintenance`, `archive`, `date_created`) VALUES ('26', 'activated', '5/1/19', 'scissor', '2', 'scissor', '567567', 'clean', '2 days', '8/4/19', '12/12/18', NULL, '2019-11-21 11:23:41');


#
# TABLE STRUCTURE FOR: files
#

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stat` varchar(255) NOT NULL DEFAULT 'activated',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `files` (`id`, `stat`, `name`, `email`, `picture`, `created`, `modified`, `status`, `date_created`) VALUES ('11', 'deactivated', 'mobile app', 'admin@gmail.com', '72664561_1006605993015699_6898389334815145984_n1.jpg', '2019-11-20 14:01:27', '2019-11-20 14:01:27', '1', '2019-11-23 00:12:47');
INSERT INTO `files` (`id`, `stat`, `name`, `email`, `picture`, `created`, `modified`, `status`, `date_created`) VALUES ('12', 'activated', 'face mask', 'admin@gmail.com', '71966934_1357277507782614_1641568184504942592_n1.jpg', '2019-11-21 03:47:26', '2019-11-21 03:47:26', '0', '2019-11-22 23:17:30');
INSERT INTO `files` (`id`, `stat`, `name`, `email`, `picture`, `created`, `modified`, `status`, `date_created`) VALUES ('13', 'activated', 'globe bills', 'admin@gmail.coms', 'Globe_Bill.pdf', '2019-11-22 12:12:39', '2019-11-22 12:12:39', '1', '2019-11-22 23:50:44');
INSERT INTO `files` (`id`, `stat`, `name`, `email`, `picture`, `created`, `modified`, `status`, `date_created`) VALUES ('17', 'activated', 'aaa', '', 'Chapter-4-A.docx', '2019-11-22 12:14:50', '2019-11-22 12:14:50', '1', '2019-11-22 19:14:50');


#
# TABLE STRUCTURE FOR: patients
#

DROP TABLE IF EXISTS `patients`;

CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_user_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'activated',
  `city` varchar(255) DEFAULT NULL,
  `incidentType` varchar(255) DEFAULT NULL,
  `incidentLocation` varchar(255) DEFAULT NULL,
  `callReceivedFrom` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `patientType` varchar(255) DEFAULT NULL,
  `timeCallReceived` varchar(255) DEFAULT NULL,
  `timeAtScene` varchar(255) DEFAULT NULL,
  `timeEndorsed` varchar(255) DEFAULT NULL,
  `ambulance` varchar(255) DEFAULT NULL,
  `birthDate` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contactNumber` varchar(255) DEFAULT NULL,
  `phMember` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `receivedFrom` varchar(255) DEFAULT NULL,
  `transportedTo` varchar(255) DEFAULT NULL,
  `run` varchar(255) DEFAULT NULL,
  `chiefComplaint` varchar(255) DEFAULT NULL,
  `time1` varchar(255) DEFAULT NULL,
  `time2` varchar(255) DEFAULT NULL,
  `time3` varchar(255) DEFAULT NULL,
  `pr1` varchar(255) DEFAULT NULL,
  `pr2` varchar(255) DEFAULT NULL,
  `pr3` varchar(255) DEFAULT NULL,
  `rr1` varchar(255) DEFAULT NULL,
  `rr2` varchar(255) DEFAULT NULL,
  `rr3` varchar(255) DEFAULT NULL,
  `bp1` varchar(255) DEFAULT NULL,
  `bp2` varchar(255) DEFAULT NULL,
  `bp3` varchar(255) DEFAULT NULL,
  `spo21` varchar(255) DEFAULT NULL,
  `spo22` varchar(255) DEFAULT NULL,
  `spo23` varchar(255) DEFAULT NULL,
  `skinColor` varchar(255) DEFAULT NULL,
  `temp` varchar(255) DEFAULT NULL,
  `n1` varchar(255) DEFAULT NULL,
  `d1` varchar(255) DEFAULT NULL,
  `c1` varchar(255) DEFAULT NULL,
  `nr1` varchar(255) DEFAULT NULL,
  `n2` varchar(255) DEFAULT NULL,
  `d2` varchar(255) DEFAULT NULL,
  `c2` varchar(255) DEFAULT NULL,
  `nr2` varchar(255) DEFAULT NULL,
  `signAndSymptoms` varchar(255) DEFAULT NULL,
  `allergies` varchar(255) DEFAULT NULL,
  `medication` varchar(255) DEFAULT NULL,
  `medicalHistory` varchar(255) DEFAULT NULL,
  `others` varchar(255) DEFAULT NULL,
  `lastOralIntake` varchar(255) DEFAULT NULL,
  `eventsPrior` varchar(255) DEFAULT NULL,
  `lmp` varchar(255) DEFAULT NULL,
  `aog` varchar(255) DEFAULT NULL,
  `edd` varchar(255) DEFAULT NULL,
  `gOb` varchar(255) DEFAULT NULL,
  `pOb` varchar(255) DEFAULT NULL,
  `initial` varchar(255) DEFAULT NULL,
  `final` varchar(255) DEFAULT NULL,
  `sexPedia` varchar(255) DEFAULT NULL,
  `babyOut` varchar(255) DEFAULT NULL,
  `placentaOut` varchar(255) DEFAULT NULL,
  `circulation` varchar(255) DEFAULT NULL,
  `breathing` varchar(255) DEFAULT NULL,
  `immobilization` varchar(255) DEFAULT NULL,
  `arrest` varchar(255) DEFAULT NULL,
  `cpr` varchar(255) DEFAULT NULL,
  `pulse` varchar(255) DEFAULT NULL,
  `disposition` varchar(255) DEFAULT NULL,
  `pending` varchar(255) DEFAULT NULL,
  `ambulanceDriver` varchar(255) DEFAULT NULL,
  `crew1` varchar(255) DEFAULT NULL,
  `crew2` varchar(255) DEFAULT NULL,
  `crew3` varchar(255) DEFAULT NULL,
  `crew4` varchar(255) DEFAULT NULL,
  `crew5` varchar(255) DEFAULT NULL,
  `crew6` varchar(255) DEFAULT NULL,
  `endorsedBy` varchar(255) DEFAULT NULL,
  `receivedBy` varchar(255) DEFAULT NULL,
  `lpm` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

INSERT INTO `patients` (`id`, `patient_user_id`, `status`, `city`, `incidentType`, `incidentLocation`, `callReceivedFrom`, `date`, `patientType`, `timeCallReceived`, `timeAtScene`, `timeEndorsed`, `ambulance`, `birthDate`, `sex`, `name`, `age`, `address`, `contactNumber`, `phMember`, `level`, `receivedFrom`, `transportedTo`, `run`, `chiefComplaint`, `time1`, `time2`, `time3`, `pr1`, `pr2`, `pr3`, `rr1`, `rr2`, `rr3`, `bp1`, `bp2`, `bp3`, `spo21`, `spo22`, `spo23`, `skinColor`, `temp`, `n1`, `d1`, `c1`, `nr1`, `n2`, `d2`, `c2`, `nr2`, `signAndSymptoms`, `allergies`, `medication`, `medicalHistory`, `others`, `lastOralIntake`, `eventsPrior`, `lmp`, `aog`, `edd`, `gOb`, `pOb`, `initial`, `final`, `sexPedia`, `babyOut`, `placentaOut`, `circulation`, `breathing`, `immobilization`, `arrest`, `cpr`, `pulse`, `disposition`, `pending`, `ambulanceDriver`, `crew1`, `crew2`, `crew3`, `crew4`, `crew5`, `crew6`, `endorsedBy`, `receivedBy`, `lpm`, `date_created`) VALUES ('29', NULL, 'activated', 'other', 'hacking', 'medical history', 'medical history', '5/1/19', 'medical', '11/23/2019 12:00 AM - 11/24/2019 12:00 AM', '11/23/2019 12:00 AM - 11/24/2019 12:00 AM', '11/23/2019 12:00 AM - 11/24/2019 12:00 AM', 'kinglong', '11/12/2019', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'no', 'alert,verbal,pain,unresponsive', 'medical history', 'medical history', 'transport,transfer,no,routine,refused,request', 'medical history', '2:45 PM', '2:45 PM', '2:45 PM', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'cyanotic', 'warm', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'HTN,DM,CVA,MI,ASTHMA', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'bleeding,control,shock,position', 'OPA,NPA,Cannula,SFM', 'collar,block,splint,spine', 'witnessed', 'medical history', 'no', 'improved', 'stretcher,spine,collar,splint', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'medical history', 'sample', '2019-11-24 19:23:33');
INSERT INTO `patients` (`id`, `patient_user_id`, `status`, `city`, `incidentType`, `incidentLocation`, `callReceivedFrom`, `date`, `patientType`, `timeCallReceived`, `timeAtScene`, `timeEndorsed`, `ambulance`, `birthDate`, `sex`, `name`, `age`, `address`, `contactNumber`, `phMember`, `level`, `receivedFrom`, `transportedTo`, `run`, `chiefComplaint`, `time1`, `time2`, `time3`, `pr1`, `pr2`, `pr3`, `rr1`, `rr2`, `rr3`, `bp1`, `bp2`, `bp3`, `spo21`, `spo22`, `spo23`, `skinColor`, `temp`, `n1`, `d1`, `c1`, `nr1`, `n2`, `d2`, `c2`, `nr2`, `signAndSymptoms`, `allergies`, `medication`, `medicalHistory`, `others`, `lastOralIntake`, `eventsPrior`, `lmp`, `aog`, `edd`, `gOb`, `pOb`, `initial`, `final`, `sexPedia`, `babyOut`, `placentaOut`, `circulation`, `breathing`, `immobilization`, `arrest`, `cpr`, `pulse`, `disposition`, `pending`, `ambulanceDriver`, `crew1`, `crew2`, `crew3`, `crew4`, `crew5`, `crew6`, `endorsedBy`, `receivedBy`, `lpm`, `date_created`) VALUES ('51', NULL, 'activated', 'tacloban', 'vehicular', 'sample', 'sample', '11/06/2019', 'medical,obgyne,psychiatric,trauma,pediatric', '11/24/2019 12:00 AM - 11/25/2019 12:00 AM', '11/25/2019 12:00 AM - 11/26/2019 11:00 PM', '11/24/2019 12:00 AM - 11/25/2019 12:00 AM', 'kimse', '11/19/2019', 'sample', 'sample', '12', 'sample', 'sample', 'yes', 'alert,verbal,pain,unresponsive', 'sample', 'sample', 'transport,transfer,no,routine,refused,request', 'sample', '8:45 PM', '7:30 PM', '8:45 PM', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'pale', 'cool', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'HTN,DM,CVA,MI,ASTHMA', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'bleeding,control,shock,position', 'OPA,NPA,Cannula,SFM', 'collar,block,splint,spine', 'un-witnessed', 'sample', 'no', 'expired', 'stretcher,spine,collar', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', 'sample', '2019-11-24 19:37:27');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES ('1', 'tanix', 'tanix', 'tanix@gmail.com', 'tanix', '1234', 'admin', '', '2019-11-18 18:23:43');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES ('2', 'admin', 'admin', 'admin@gmail.com', 'admin', 'admin', 'admin', '', '2019-11-18 18:23:49');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES ('3', 'staff', 'staff', 'staff@gmail.com', 'staff', 'staff', 'staff', '', '2019-11-18 14:08:01');


