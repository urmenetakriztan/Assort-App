#
# TABLE STRUCTURE FOR: activity_logs
#

DROP TABLE IF EXISTS `activity_logs`;

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) DEFAULT NULL,
  `activity_id` varchar(255) DEFAULT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;

INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (6, 'leztry', NULL, 'Leztry data edited', '2020-03-27 23:28:25');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (7, 'leztry', NULL, 'Leztry data archived', '2020-03-27 23:29:50');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (8, 'leztry', NULL, 'Leztry data activated', '2020-03-27 23:31:10');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (9, 'gggg', NULL, 'Gggg equipment edited', '2020-03-27 23:35:05');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (10, 'gggg', NULL, 'Gggg equipment data archived', '2020-03-27 23:37:14');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (11, 'gggg', NULL, 'Gggg equipment data activated', '2020-03-27 23:37:19');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (12, 'gasdghsjdaa', NULL, 'Gasdghsjdaa file edited', '2020-03-27 23:52:16');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (13, 'gasdghsjdaa', NULL, 'Gasdghsjdaa file data activated', '2020-03-27 23:52:32');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (14, 'gasdghsjdaa', NULL, 'Gasdghsjdaa file data archived', '2020-03-27 23:52:38');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (15, 'yuyuy', NULL, 'Yuyuy file data created', '2020-03-27 23:53:33');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (16, 'yuyuy', NULL, 'Yuyuy file data activated', '2020-03-27 23:55:50');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (17, 'plplplp', 'staff', 'Plplplp patient created', '2020-03-28 00:10:53');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (18, 'example', NULL, 'Example patient data created', '2020-03-30 18:35:37');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (19, 'example', NULL, 'Example patient data edited', '2020-03-30 19:22:32');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (20, 'example', NULL, 'Example patient data edited', '2020-03-30 19:29:47');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (21, 'example', NULL, 'Example patient data edited', '2020-03-30 19:36:27');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (22, 'example', NULL, 'Example patient data edited', '2020-03-30 19:36:46');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (23, 'example', NULL, 'Example patient data edited', '2020-03-30 21:49:51');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (24, 'example', NULL, 'Example patient data edited', '2020-03-30 21:51:08');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (25, 'example', NULL, 'Example patient data created', '2020-03-30 22:50:15');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (26, 'example', NULL, 'Example patient data edited', '2020-03-30 22:58:34');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (27, 'example2', NULL, 'Example2 patient data created', '2020-03-30 23:05:07');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (28, 'example', NULL, 'Example patient data edited', '2020-03-30 23:07:32');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (29, 'example2', NULL, 'Example2 patient data edited', '2020-03-30 23:11:00');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (30, 'exampl3', NULL, 'Exampl3 patient data created', '2020-03-30 23:16:22');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (31, 'example4', NULL, 'Example4 patient data created', '2020-03-30 23:17:55');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (32, 'lol', NULL, 'Lol patient data created', '2020-03-30 23:50:17');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (33, 'example2', NULL, 'Example2 patient data edited', '2020-03-31 00:29:47');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (34, 'lol', NULL, 'Lol patient data edited', '2020-03-31 00:30:09');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (35, 'example4', NULL, 'Example4 patient data created', '2020-03-31 15:40:45');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (36, 'example4', NULL, 'Example4 patient data edited', '2020-03-31 15:49:17');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (37, 'example2', NULL, 'Example2 patient data edited', '2020-03-31 15:51:03');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (38, 'example4', NULL, 'Example4 patient data edited', '2020-03-31 15:51:20');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (39, 'example4', NULL, 'Example4 patient data edited', '2020-03-31 16:00:26');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (40, 'example4', NULL, 'Example4 patient data edited', '2020-03-31 16:00:47');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (41, 'example4', NULL, 'Example4 patient created', '2020-03-31 16:32:40');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (42, 'example2', NULL, 'Example2 patient data edited', '2020-03-31 16:36:40');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (43, 'lol', NULL, 'Lol patient data edited', '2020-03-31 16:38:23');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (44, 'lol', NULL, 'Lol patient created', '2020-03-31 16:42:53');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (45, 'gggs', NULL, 'Gggs crew edited', '2020-03-31 16:48:13');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (46, 'lalallaa', NULL, 'Lalallaa crew created', '2020-03-31 16:48:21');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (47, 'lalallaa', NULL, 'Lalallaa crew archived', '2020-03-31 16:48:30');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (48, 'lalallaa', NULL, 'Lalallaa crew activated', '2020-03-31 16:48:39');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (49, NULL, NULL, ' data archived', '2020-03-31 18:36:47');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (50, NULL, NULL, ' data activated', '2020-03-31 18:37:46');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (51, NULL, NULL, ' file data archived', '2020-03-31 19:47:11');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (52, NULL, NULL, ' file data archived', '2020-03-31 19:52:35');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (53, NULL, NULL, ' file data activated', '2020-03-31 19:52:54');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (54, NULL, NULL, ' equipment data archived', '2020-03-31 20:50:17');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (55, NULL, NULL, ' equipment data activated', '2020-03-31 20:54:27');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (56, 'ggggs', NULL, 'Ggggs equipment edited', '2020-03-31 21:06:56');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (57, NULL, NULL, ' data archived', '2020-04-01 12:12:06');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (58, NULL, NULL, ' data activated', '2020-04-01 12:19:38');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (59, 'tan', NULL, 'Tan file data created', '2020-04-01 12:44:40');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (60, 'tan', NULL, 'Tan file data archived', '2020-04-01 12:55:01');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (61, 'tan', NULL, 'Tan file data activated', '2020-04-01 12:57:14');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (62, NULL, NULL, ' equipment data archived', '2020-04-01 16:19:35');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (63, 'lalalas', NULL, 'Lalalas equipment edited', '2020-04-01 16:22:36');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (64, 'lalalas', NULL, 'Lalalas equipment edited', '2020-04-01 16:23:35');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (65, 'example4', NULL, 'Example4 patient data edited', '2020-04-02 13:58:14');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (66, 'example4', NULL, 'Example4 data activated', '2020-04-02 13:59:08');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (67, 'example4', NULL, 'Example4 data archived', '2020-04-02 13:59:13');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (68, 'example4', NULL, 'Example4 data activated', '2020-04-02 13:59:23');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (69, 'tans', NULL, 'Tans file edited', '2020-04-02 13:59:42');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (70, 'tans', NULL, 'Tans file edited', '2020-04-02 14:01:05');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (71, 'tans', NULL, 'Tans file data archived', '2020-04-02 14:01:11');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (72, 'tans', NULL, 'Tans file data activated', '2020-04-02 14:01:17');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (73, 'lalala', NULL, 'Lalala equipment edited', '2020-04-02 14:01:58');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (74, 'lalala', NULL, 'Lalala equipment data archived', '2020-04-02 14:02:02');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (75, 'lalala', NULL, 'Lalala equipment data activated', '2020-04-02 14:02:13');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (76, NULL, NULL, ' account edited', '2020-04-02 14:06:17');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (77, NULL, NULL, ' crew archived', '2020-04-02 14:06:54');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (78, 'gasdgh', NULL, 'Gasdgh file edited', '2020-04-02 14:20:54');
INSERT INTO `activity_logs` (`id`, `user`, `activity_id`, `activity`, `date`) VALUES (79, 'gasdgh', NULL, 'Gasdgh file data archived', '2020-04-02 14:20:59');


#
# TABLE STRUCTURE FOR: chat
#

DROP TABLE IF EXISTS `chat`;

CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receiver` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m8vcs68rkl3re4sp2ro71b7fmd5chd7p', '::1', 1585710073, '__ci_last_regenerate|i:1585710071;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8g773e4omcbu8lkdsp1n10i4ed728dql', '::1', 1585710961, '__ci_last_regenerate|i:1585710664;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tmiqqajsldm1sa4j5atqke2eiftvddru', '::1', 1585711264, '__ci_last_regenerate|i:1585710965;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1ev5n2h6fn4u7q3u3bcmfm5hh0k2n28k', '::1', 1585711741, '__ci_last_regenerate|i:1585711478;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v9e39ke7sf1rd58bhhn3l04ig5kffuva', '::1', 1585712108, '__ci_last_regenerate|i:1585711861;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2398s13n68vn3r4ra3hu6hqonq9uhcj8', '::1', 1585712327, '__ci_last_regenerate|i:1585712176;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('189lsf2ha9gnndv4q6kd50cmsahaiiuf', '::1', 1585712970, '__ci_last_regenerate|i:1585712674;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9bmkvpg1jjcomg90mn64ta45pasa5bfg', '::1', 1585713276, '__ci_last_regenerate|i:1585712990;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7sd1vbiq1aa0ik8lbsv44nhhbebehi42', '::1', 1585713736, '__ci_last_regenerate|i:1585713568;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7u3l41l8hv7do8tb0s0t9o3ld1uvuii1', '::1', 1585714193, '__ci_last_regenerate|i:1585713907;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vp8ar1rfntreq3htsctmnnn6aole01t5', '::1', 1585714464, '__ci_last_regenerate|i:1585714211;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('68ee14romu9cvfnued2mfnu6pu3c6t5p', '::1', 1585714881, '__ci_last_regenerate|i:1585714586;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6s6peqdb9p6g35gq3stvit05m1j0lefu', '::1', 1585715171, '__ci_last_regenerate|i:1585714927;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lr3lcaln7ormcpovp453hli0j7jl164j', '::1', 1585715497, '__ci_last_regenerate|i:1585715257;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k59ehmk19645dfuuh02nnfra4vt6pfa5', '::1', 1585715823, '__ci_last_regenerate|i:1585715561;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('koas0qk207ip1me0mmnsc732um8ji7lh', '::1', 1585716132, '__ci_last_regenerate|i:1585715940;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pvuv44q0s5b2sqrcg6ke72sf1kk69ufn', '::1', 1585716564, '__ci_last_regenerate|i:1585716266;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;file_user_id|s:1:\"3\";name|s:3:\"tan\";email|s:3:\"tan\";picture|s:13:\"IMG_26791.PNG\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pr5o57kv6v96d8pek29jid2mf3s09vih', '::1', 1585716776, '__ci_last_regenerate|i:1585716574;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;file_user_id|s:1:\"3\";name|s:3:\"tan\";email|s:3:\"tan\";picture|s:13:\"IMG_26791.PNG\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('01cpc71rsblkg5gkhesusea9l57m632b', '::1', 1585717140, '__ci_last_regenerate|i:1585716896;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;file_user_id|s:1:\"3\";name|s:3:\"tan\";email|s:3:\"tan\";picture|s:13:\"IMG_26791.PNG\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rnfl94utq9u6j9lng5tkcqllt71kme7c', '::1', 1585728476, '__ci_last_regenerate|i:1585728284;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6cnc5oqumr3vkidpdg04v9jopf6okqi8', '::1', 1585729078, '__ci_last_regenerate|i:1585728782;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ppu2nj1aonrmb2unt4tl83o6poisgl27', '::1', 1585729415, '__ci_last_regenerate|i:1585729122;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;model|s:7:\"lalalas\";quantity|s:6:\"lalala\";equipment_type|s:6:\"lalala\";maintenancePerformed|s:6:\"lalala\";maintenanceFrequency|s:6:\"lalala\";previousMaintenance|s:10:\"02/09/2020\";nextMaintenance|s:10:\"02/18/2020\";storage|s:6:\"lalala\";date|s:10:\"02/18/2020\";equipment_updated|s:36:\"Your equipment data has been updated\";__ci_vars|a:1:{s:17:\"equipment_updated\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sd9ds07d1idp48j83vpjaqhk19qvl04v', '::1', 1585729748, '__ci_last_regenerate|i:1585729476;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;model|s:7:\"lalalas\";quantity|s:6:\"lalala\";equipment_type|s:6:\"lalala\";maintenancePerformed|s:6:\"lalala\";maintenanceFrequency|s:6:\"lalala\";previousMaintenance|s:10:\"02/09/2020\";nextMaintenance|s:10:\"02/18/2020\";storage|s:6:\"lalala\";date|s:10:\"02/18/2020\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j3nh2aa4ar0ep7c9pee63f18a47i1d2l', '::1', 1585730155, '__ci_last_regenerate|i:1585729861;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;model|s:7:\"lalalas\";quantity|s:6:\"lalala\";equipment_type|s:6:\"lalala\";maintenancePerformed|s:6:\"lalala\";maintenanceFrequency|s:6:\"lalala\";previousMaintenance|s:10:\"02/09/2020\";nextMaintenance|s:10:\"02/18/2020\";storage|s:6:\"lalala\";date|s:10:\"02/18/2020\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rbsaqvbokcmfeakdlb96pf431t9s3prk', '::1', 1585730514, '__ci_last_regenerate|i:1585730246;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;model|s:7:\"lalalas\";quantity|s:6:\"lalala\";equipment_type|s:6:\"lalala\";maintenancePerformed|s:6:\"lalala\";maintenanceFrequency|s:6:\"lalala\";previousMaintenance|s:10:\"02/09/2020\";nextMaintenance|s:10:\"02/18/2020\";storage|s:6:\"lalala\";date|s:10:\"02/18/2020\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cggrodlki0cfqgivm9no8ldnns6gdegr', '::1', 1585730992, '__ci_last_regenerate|i:1585730752;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uvq7o1t7okiskq6bfqli9c7bu4lpvumo', '::1', 1585731386, '__ci_last_regenerate|i:1585731126;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0f1s4gc9u64gh2dj1pnnfjd9i4skis4m', '::1', 1585731642, '__ci_last_regenerate|i:1585731452;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tsgi1rojlb9op1gpc6qqme0sbnch2eb2', '::1', 1585732162, '__ci_last_regenerate|i:1585731863;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kbd0hhsejkshuqeodrbtgiauvg6h4ijj', '::1', 1585732388, '__ci_last_regenerate|i:1585732173;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mp9v0a7o8pl92p778g1ks8dvkkdvim78', '::1', 1585732627, '__ci_last_regenerate|i:1585732581;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u52nqgcu4eou1gukqba4dk1ubh5hdk83', '::1', 1585733180, '__ci_last_regenerate|i:1585732888;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sco8udcn7q8ia0b63mqbv9ok82odam46', '::1', 1585733427, '__ci_last_regenerate|i:1585733209;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('clpq8ldvh7e7o8p9081fs9f2rbham76u', '::1', 1585733560, '__ci_last_regenerate|i:1585733558;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j8jeg4savqtejnk0hlcsboke57sloksg', '::1', 1585806869, '__ci_last_regenerate|i:1585806632;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('uljtlmue7k3qsrfjphin3a8t3gtjlbrd', '::1', 1585807302, '__ci_last_regenerate|i:1585807004;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;city|s:8:\"tacloban\";incidentType|s:9:\"vehicular\";incidentLocation|s:8:\"example4\";callReceivedFrom|s:5:\"radio\";date|s:10:\"03/01/2020\";timeCallReceived|s:41:\"03/31/2020 12:00 AM - 04/01/2020 12:00 AM\";timeAtScene|s:41:\"03/31/2020 12:00 AM - 04/01/2020 12:00 AM\";timeEndorsed|s:41:\"03/31/2020 12:00 AM - 04/01/2020 12:00 AM\";ambulance|s:5:\"kimse\";name|s:4:\"tans\";age|s:2:\"93\";birthDate|s:10:\"03/16/1927\";sex|s:4:\"male\";address|s:8:\"example4\";contactNumber|s:12:\"092828288282\";phMember|s:3:\"yes\";receivedFrom|s:8:\"example4\";transportedTo|s:8:\"example4\";chiefComplaint|s:8:\"example4\";time1|s:7:\"3:45 PM\";time2|s:7:\"3:45 PM\";time3|s:7:\"3:45 PM\";pr1|s:1:\"1\";pr2|s:1:\"1\";pr3|s:1:\"1\";rr1|s:1:\"1\";rr2|s:1:\"1\";rr3|s:1:\"1\";bp1|s:1:\"1\";bp2|s:1:\"1\";bp3|s:1:\"1\";spo21|s:1:\"1\";spo22|s:1:\"1\";spo23|s:1:\"1\";skinColor|N;temp|N;signAndSymptoms|s:8:\"example4\";allergies|s:8:\"example4\";medication|s:8:\"example4\";lastOralIntake|s:8:\"example4\";eventsPrior|s:8:\"example4\";lmp|s:10:\"03/01/2020\";aog|s:10:\"03/01/2020\";edd|s:10:\"03/01/2020\";gOb|s:8:\"example4\";pOb|s:8:\"example4\";initial|s:1:\"1\";final|s:1:\"1\";sexPedia|s:10:\"03/01/2020\";babyOut|s:10:\"03/01/2020\";placentaOut|s:10:\"03/01/2020\";cpr|s:8:\"example4\";ambulanceDriver|s:7:\"sssssss\";crew1|s:4:\"None\";crew2|s:4:\"None\";crew3|s:4:\"None\";crew4|s:4:\"None\";crew5|s:4:\"None\";crew6|s:4:\"None\";endorsedBy|s:8:\"example4\";receivedBy|s:8:\"example4\";arrest|N;pulse|N;disposition|N;others|s:8:\"example4\";lpm|s:8:\"example4\";vehicleInvolved|s:8:\"example4\";plate|s:8:\"example4\";mvcothers|s:8:\"example4\";pedothers|s:8:\"example4\";narrative|s:8:\"example4\";leftPupil|s:6:\"normal\";rightPupil|s:6:\"normal\";run|s:19:\"Emergency Transport\";tri|N;level|N;patientType|N;injuries|N;ped|N;mvc|N;pending|N;immobilization|N;breathing|s:7:\"OPA,NPA\";circulation|N;medicalHistory|s:6:\"HTN,DM\";email|s:3:\"tan\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1uqrb0q071cld34u0pt5qanjp5u1k2mq', '::1', 1585807770, '__ci_last_regenerate|i:1585807554;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;first_name|s:6:\"admins\";last_name|s:5:\"admin\";email|s:15:\"admin@gmail.com\";password|s:5:\"admin\";status|s:9:\"activated\";role_id|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6ut1rb3egoc9tbq7ncbt483qrc5v6net', '::1', 1585808175, '__ci_last_regenerate|i:1585807886;user_id|s:1:\"2\";username|s:5:\"admin\";type|s:5:\"admin\";logged_in|b:1;first_name|s:6:\"admins\";last_name|s:5:\"admin\";email|s:15:\"admin@gmail.com\";password|s:5:\"admin\";status|s:9:\"activated\";role_id|s:5:\"admin\";');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hrodi8m7bs3stu2s241kavtoi3abtg29', '::1', 1585808527, '__ci_last_regenerate|i:1585808504;user_id|s:1:\"3\";username|s:5:\"staff\";type|s:5:\"staff\";logged_in|b:1;');


#
# TABLE STRUCTURE FOR: crew
#

DROP TABLE IF EXISTS `crew`;

CREATE TABLE `crew` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT 'activated',
  `crewn` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `crewmn` varchar(255) NOT NULL,
  `crewln` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `crew` (`id`, `status`, `crewn`, `position`, `crewmn`, `crewln`, `date_created`) VALUES (1, 'hidden', 'None', 'Crew', '', '', '2020-03-31 16:41:40');
INSERT INTO `crew` (`id`, `status`, `crewn`, `position`, `crewmn`, `crewln`, `date_created`) VALUES (2, 'activated', 'sssssss', 'Driver', 'sssssssss', 'sssssssssss', '2020-03-31 16:48:39');
INSERT INTO `crew` (`id`, `status`, `crewn`, `position`, `crewmn`, `crewln`, `date_created`) VALUES (3, 'deactivated', 'gggs', 'Crew', 'ggg', 'gggg', '2020-04-02 14:06:53');
INSERT INTO `crew` (`id`, `status`, `crewn`, `position`, `crewmn`, `crewln`, `date_created`) VALUES (4, 'activated', 'grrrrr', 'Driver', '', '', '2020-03-31 16:42:53');
INSERT INTO `crew` (`id`, `status`, `crewn`, `position`, `crewmn`, `crewln`, `date_created`) VALUES (5, 'activated', 'lalallaa', 'Driver', '', '', '2020-03-31 16:48:21');


#
# TABLE STRUCTURE FOR: equipments
#

DROP TABLE IF EXISTS `equipments`;

CREATE TABLE `equipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT 'activated',
  `date` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `equipment_type` varchar(255) NOT NULL,
  `maintenancePerformed` varchar(255) NOT NULL,
  `maintenanceFrequency` varchar(255) NOT NULL,
  `previousMaintenance` varchar(255) NOT NULL,
  `nextMaintenance` varchar(255) NOT NULL,
  `storage` varchar(255) DEFAULT NULL,
  `archive` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `equipments` (`id`, `status`, `date`, `model`, `quantity`, `equipment_type`, `maintenancePerformed`, `maintenanceFrequency`, `previousMaintenance`, `nextMaintenance`, `storage`, `archive`, `date_created`) VALUES (1, 'activated', '01/22/2020', 'tae', '', 'tae', 'tae', '1', '01/21/2020', '01/28/2020', NULL, NULL, '2020-01-11 12:21:26');
INSERT INTO `equipments` (`id`, `status`, `date`, `model`, `quantity`, `equipment_type`, `maintenancePerformed`, `maintenanceFrequency`, `previousMaintenance`, `nextMaintenance`, `storage`, `archive`, `date_created`) VALUES (2, 'deactivated', '01/15/2020', 'ggggs', '4', 'ggg', 'ggg', '1', '11/02/2019', '01/27/2020', 'ggg', 'activated', '2020-01-11 12:22:03');
INSERT INTO `equipments` (`id`, `status`, `date`, `model`, `quantity`, `equipment_type`, `maintenancePerformed`, `maintenanceFrequency`, `previousMaintenance`, `nextMaintenance`, `storage`, `archive`, `date_created`) VALUES (3, 'activated', '02/18/2020', 'lalala', 'lalala', 'lalala', 'lalala', 'lalala', '02/09/2020', '02/18/2020', 'lalala', NULL, '2020-02-09 14:23:38');
INSERT INTO `equipments` (`id`, `status`, `date`, `model`, `quantity`, `equipment_type`, `maintenancePerformed`, `maintenanceFrequency`, `previousMaintenance`, `nextMaintenance`, `storage`, `archive`, `date_created`) VALUES (4, 'activated', '02/26/2020', 'tacru', '3', 'tacru', 'tacru', '5', '02/05/2020', '02/19/2020', 'tacru', NULL, '2020-02-16 19:27:37');


#
# TABLE STRUCTURE FOR: events
#

DROP TABLE IF EXISTS `events`;

CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `color` varchar(7) NOT NULL DEFAULT '#3a87ad',
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `allday` varchar(50) NOT NULL DEFAULT 'true',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `events` (`id`, `title`, `description`, `color`, `start`, `end`, `allday`) VALUES (4, 'yow', 'asdasdasdasdasd', '#3a87ad', '2020-03-11 00:00:00', '2020-03-16 00:00:00', 'true');
INSERT INTO `events` (`id`, `title`, `description`, `color`, `start`, `end`, `allday`) VALUES (5, 'asda', 'sjsjj', '#3a87ad', '2020-03-04 00:00:00', '2020-03-05 00:00:00', 'true');
INSERT INTO `events` (`id`, `title`, `description`, `color`, `start`, `end`, `allday`) VALUES (6, 'Customer Service', '123123', '#3a87ad', '2020-03-05 00:00:00', '2020-03-06 00:00:00', 'true');
INSERT INTO `events` (`id`, `title`, `description`, `color`, `start`, `end`, `allday`) VALUES (7, 'gagad', 'gagasss', '#3a87ad', '2020-04-01 00:00:00', '2020-04-02 00:00:00', 'true');
INSERT INTO `events` (`id`, `title`, `description`, `color`, `start`, `end`, `allday`) VALUES (8, 'gsgs', 'sdfsf', '#3a87ad', '2020-03-31 00:00:00', '2020-04-01 00:00:00', 'true');
INSERT INTO `events` (`id`, `title`, `description`, `color`, `start`, `end`, `allday`) VALUES (9, 'Customer Servicesg', 'sssssss', '#c0e81e', '2020-04-08 00:00:00', '2020-04-09 00:00:00', 'true');
INSERT INTO `events` (`id`, `title`, `description`, `color`, `start`, `end`, `allday`) VALUES (10, 'asdx', 'asdx', '#3a87ad', '2020-04-02 00:00:00', '2020-04-03 00:00:00', 'true');


#
# TABLE STRUCTURE FOR: feedbacks
#

DROP TABLE IF EXISTS `feedbacks`;

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) DEFAULT 'activated',
  `feedback` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `feedbacks` (`id`, `status`, `feedback`, `email`, `comment`, `date_created`) VALUES (1, 'activated', 'compliment', 'asdasd', 'asdasdasd', '2020-03-31 22:04:26');
INSERT INTO `feedbacks` (`id`, `status`, `feedback`, `email`, `comment`, `date_created`) VALUES (2, 'activated', 'compliment', 'sssdadad', 'asdasd', '2020-03-30 18:22:55');


#
# TABLE STRUCTURE FOR: files
#

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_user_id` int(11) NOT NULL,
  `stat` varchar(255) NOT NULL DEFAULT 'activated',
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `files` (`id`, `file_user_id`, `stat`, `name`, `email`, `picture`, `created`, `modified`, `status`, `date_created`) VALUES (7, 2, 'deactivated', 'gasdgh', 'sdfhjkl@gmail.com', '41475899_243674829683244_8262958405338005504_n.jpg', '2020-02-10 00:33:09', '2020-02-10 00:33:09', 1, '2020-04-02 14:20:59');
INSERT INTO `files` (`id`, `file_user_id`, `stat`, `name`, `email`, `picture`, `created`, `modified`, `status`, `date_created`) VALUES (8, 2, 'activated', 'nice', 'Nice', '625FF84A-5AE0-4AA6-BF0F-3DB6748A9342.jpeg', '2020-02-16 03:29:35', '2020-02-16 03:29:35', 1, '2020-03-27 23:55:50');
INSERT INTO `files` (`id`, `file_user_id`, `stat`, `name`, `email`, `picture`, `created`, `modified`, `status`, `date_created`) VALUES (9, 2, 'deactivated', 'yuyuy', 'yuyuy', 'IMG_2679.PNG', '2020-03-27 16:53:33', '2020-03-27 16:53:33', 1, '2020-03-31 19:52:35');
INSERT INTO `files` (`id`, `file_user_id`, `stat`, `name`, `email`, `picture`, `created`, `modified`, `status`, `date_created`) VALUES (10, 3, 'activated', 'tans', 'tan', 'IMG_26791.PNG', '2020-04-01 06:44:40', '2020-04-01 06:44:40', 1, '2020-04-02 14:01:17');


#
# TABLE STRUCTURE FOR: patients
#

DROP TABLE IF EXISTS `patients`;

CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_user_id` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'activated',
  `city` varchar(255) DEFAULT NULL,
  `incidentType` varchar(255) DEFAULT NULL,
  `incidentLocation` varchar(255) DEFAULT NULL,
  `callReceivedFrom` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `patientType` varchar(255) DEFAULT NULL,
  `timeCallReceived` varchar(255) DEFAULT NULL,
  `timeAtScene` varchar(255) DEFAULT NULL,
  `timeEndorsed` varchar(255) DEFAULT NULL,
  `ambulance` varchar(255) DEFAULT NULL,
  `birthDate` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `age` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contactNumber` varchar(255) DEFAULT NULL,
  `phMember` varchar(255) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `receivedFrom` varchar(255) DEFAULT NULL,
  `transportedTo` varchar(255) DEFAULT NULL,
  `run` varchar(255) DEFAULT NULL,
  `chiefComplaint` varchar(255) DEFAULT NULL,
  `time1` varchar(255) DEFAULT NULL,
  `time2` varchar(255) DEFAULT NULL,
  `time3` varchar(255) DEFAULT NULL,
  `pr1` varchar(255) DEFAULT NULL,
  `pr2` varchar(255) DEFAULT NULL,
  `pr3` varchar(255) DEFAULT NULL,
  `rr1` varchar(255) DEFAULT NULL,
  `rr2` varchar(255) DEFAULT NULL,
  `rr3` varchar(255) DEFAULT NULL,
  `bp1` varchar(255) DEFAULT NULL,
  `bp2` varchar(255) DEFAULT NULL,
  `bp3` varchar(255) DEFAULT NULL,
  `spo21` varchar(255) DEFAULT NULL,
  `spo22` varchar(255) DEFAULT NULL,
  `spo23` varchar(255) DEFAULT NULL,
  `skinColor` varchar(255) DEFAULT NULL,
  `temp` varchar(255) DEFAULT NULL,
  `leftPupil` varchar(255) DEFAULT NULL,
  `rightPupil` varchar(255) DEFAULT NULL,
  `signAndSymptoms` varchar(255) DEFAULT NULL,
  `allergies` varchar(255) DEFAULT NULL,
  `medication` varchar(255) DEFAULT NULL,
  `medicalHistory` varchar(255) DEFAULT NULL,
  `others` varchar(255) DEFAULT NULL,
  `lastOralIntake` varchar(255) DEFAULT NULL,
  `eventsPrior` varchar(255) DEFAULT NULL,
  `lmp` varchar(255) DEFAULT NULL,
  `aog` varchar(255) DEFAULT NULL,
  `edd` varchar(255) DEFAULT NULL,
  `gOb` varchar(255) DEFAULT NULL,
  `pOb` varchar(255) DEFAULT NULL,
  `initial` varchar(255) DEFAULT NULL,
  `final` varchar(255) DEFAULT NULL,
  `sexPedia` varchar(255) DEFAULT NULL,
  `babyOut` varchar(255) DEFAULT NULL,
  `placentaOut` varchar(255) DEFAULT NULL,
  `circulation` varchar(255) DEFAULT NULL,
  `breathing` varchar(255) DEFAULT NULL,
  `immobilization` varchar(255) DEFAULT NULL,
  `arrest` varchar(255) DEFAULT NULL,
  `cpr` varchar(255) DEFAULT NULL,
  `pulse` varchar(255) DEFAULT NULL,
  `disposition` varchar(255) DEFAULT NULL,
  `pending` varchar(255) DEFAULT NULL,
  `ambulanceDriver` varchar(255) DEFAULT NULL,
  `crew1` varchar(255) DEFAULT NULL,
  `crew2` varchar(255) DEFAULT NULL,
  `crew3` varchar(255) DEFAULT NULL,
  `crew4` varchar(255) DEFAULT NULL,
  `crew5` varchar(255) DEFAULT NULL,
  `crew6` varchar(255) DEFAULT NULL,
  `endorsedBy` varchar(255) DEFAULT NULL,
  `receivedBy` varchar(255) DEFAULT NULL,
  `lpm` varchar(255) DEFAULT NULL,
  `vehicleInvolved` varchar(255) DEFAULT NULL,
  `plate` varchar(255) DEFAULT NULL,
  `mvc` varchar(255) DEFAULT NULL,
  `mvcothers` varchar(255) DEFAULT NULL,
  `ped` varchar(255) DEFAULT NULL,
  `pedothers` varchar(255) DEFAULT NULL,
  `tri` varchar(255) DEFAULT NULL,
  `narrative` varchar(255) DEFAULT NULL,
  `injuries` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `patients` (`id`, `patient_user_id`, `status`, `city`, `incidentType`, `incidentLocation`, `callReceivedFrom`, `date`, `patientType`, `timeCallReceived`, `timeAtScene`, `timeEndorsed`, `ambulance`, `birthDate`, `sex`, `name`, `age`, `address`, `contactNumber`, `phMember`, `level`, `receivedFrom`, `transportedTo`, `run`, `chiefComplaint`, `time1`, `time2`, `time3`, `pr1`, `pr2`, `pr3`, `rr1`, `rr2`, `rr3`, `bp1`, `bp2`, `bp3`, `spo21`, `spo22`, `spo23`, `skinColor`, `temp`, `leftPupil`, `rightPupil`, `signAndSymptoms`, `allergies`, `medication`, `medicalHistory`, `others`, `lastOralIntake`, `eventsPrior`, `lmp`, `aog`, `edd`, `gOb`, `pOb`, `initial`, `final`, `sexPedia`, `babyOut`, `placentaOut`, `circulation`, `breathing`, `immobilization`, `arrest`, `cpr`, `pulse`, `disposition`, `pending`, `ambulanceDriver`, `crew1`, `crew2`, `crew3`, `crew4`, `crew5`, `crew6`, `endorsedBy`, `receivedBy`, `lpm`, `vehicleInvolved`, `plate`, `mvc`, `mvcothers`, `ped`, `pedothers`, `tri`, `narrative`, `injuries`, `date_created`) VALUES (26, NULL, 'activated', 'tacloban', 'vehicular', 'example2', 'radio', '03/01/2020', 'None', '03/30/2020 12:00 AM - 03/31/2020 12:00 AM', '03/30/2020 12:00 AM - 03/31/2020 12:00 AM', '03/30/2020 12:00 AM - 03/31/2020 12:00 AM', 'kimse', '03/01/2020', 'male', 'example2', '0', 'example2', '0928282822882', 'yes', 'None', 'example2', 'example2', 'None', 'example2example2', '11:15 PM', '11:15 PM', '11:15 PM', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 'None', 'None', 'normal', 'normal', 'example2', 'example2', 'example2', 'MI,ASTHMA', 'example2', 'example2', 'example2', '03/01/2020', '03/01/2020', '03/01/2020', 'example2', 'example2', '1', '1', '03/01/2020', '03/01/2020', '03/01/2020', 'Shock,Position', 'SFM,BVM', 'Splint,Spine', 'None', 'example2', 'None', 'None', 'Collar,Splint', 'sssssss', 'ggg', 'None', 'None', 'None', 'None', 'None', 'example2', 'example2', 'example2', 'example2', 'example2', 'Mvcrotations,Roll', 'example2', 'Flail,Burn', 'example2', 'None', 'example2example2', 'Fracture,Dislocation,Avuision', '2020-03-31 18:37:46');
INSERT INTO `patients` (`id`, `patient_user_id`, `status`, `city`, `incidentType`, `incidentLocation`, `callReceivedFrom`, `date`, `patientType`, `timeCallReceived`, `timeAtScene`, `timeEndorsed`, `ambulance`, `birthDate`, `sex`, `name`, `age`, `address`, `contactNumber`, `phMember`, `level`, `receivedFrom`, `transportedTo`, `run`, `chiefComplaint`, `time1`, `time2`, `time3`, `pr1`, `pr2`, `pr3`, `rr1`, `rr2`, `rr3`, `bp1`, `bp2`, `bp3`, `spo21`, `spo22`, `spo23`, `skinColor`, `temp`, `leftPupil`, `rightPupil`, `signAndSymptoms`, `allergies`, `medication`, `medicalHistory`, `others`, `lastOralIntake`, `eventsPrior`, `lmp`, `aog`, `edd`, `gOb`, `pOb`, `initial`, `final`, `sexPedia`, `babyOut`, `placentaOut`, `circulation`, `breathing`, `immobilization`, `arrest`, `cpr`, `pulse`, `disposition`, `pending`, `ambulanceDriver`, `crew1`, `crew2`, `crew3`, `crew4`, `crew5`, `crew6`, `endorsedBy`, `receivedBy`, `lpm`, `vehicleInvolved`, `plate`, `mvc`, `mvcothers`, `ped`, `pedothers`, `tri`, `narrative`, `injuries`, `date_created`) VALUES (29, NULL, 'activated', 'tacloban', 'vehicular', 'lol', 'radio', '03/01/2020', 'Medical', '03/30/2020 12:00 AM - 03/31/2020 12:00 AM', '03/30/2020 12:00 AM - 03/31/2020 12:00 AM', '03/30/2020 12:00 AM - 03/31/2020 12:00 AM', 'kimse', '03/01/2020', 'male', 'lol', '0', 'lol', '092828282', 'yes', 'None', 'lol', 'lol', 'None', 'lol', '12:00 PM', '12:00 PM', '12:00 PM', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', 'None', 'None', 'normal', 'normal', 'lol', 'lol', 'lol', 'MI,ASTHMA', 'lol', 'lol', 'lol', '03/01/2020', '03/01/2020', '03/01/2020', 'lol', 'lol', '1', '1', '03/01/2020', '03/01/2020', '03/01/2020', 'Shock,Position', 'SFM,BVM', 'Splint,Spine', 'None', 'lol', 'None', 'None', 'Collar,Splint', 'sssssss', 'ggg', 'sssssss', 'None', 'None', 'None', 'None', 'lol', 'lol', 'lol', 'lol', 'lol', 'Mvcrotations,Roll', 'lol', 'Flail,Burn', 'lol', 'None', 'lollol', 'Dislocation,Avuision', '2020-03-31 16:38:23');
INSERT INTO `patients` (`id`, `patient_user_id`, `status`, `city`, `incidentType`, `incidentLocation`, `callReceivedFrom`, `date`, `patientType`, `timeCallReceived`, `timeAtScene`, `timeEndorsed`, `ambulance`, `birthDate`, `sex`, `name`, `age`, `address`, `contactNumber`, `phMember`, `level`, `receivedFrom`, `transportedTo`, `run`, `chiefComplaint`, `time1`, `time2`, `time3`, `pr1`, `pr2`, `pr3`, `rr1`, `rr2`, `rr3`, `bp1`, `bp2`, `bp3`, `spo21`, `spo22`, `spo23`, `skinColor`, `temp`, `leftPupil`, `rightPupil`, `signAndSymptoms`, `allergies`, `medication`, `medicalHistory`, `others`, `lastOralIntake`, `eventsPrior`, `lmp`, `aog`, `edd`, `gOb`, `pOb`, `initial`, `final`, `sexPedia`, `babyOut`, `placentaOut`, `circulation`, `breathing`, `immobilization`, `arrest`, `cpr`, `pulse`, `disposition`, `pending`, `ambulanceDriver`, `crew1`, `crew2`, `crew3`, `crew4`, `crew5`, `crew6`, `endorsedBy`, `receivedBy`, `lpm`, `vehicleInvolved`, `plate`, `mvc`, `mvcothers`, `ped`, `pedothers`, `tri`, `narrative`, `injuries`, `date_created`) VALUES (30, 3, 'activated', 'tacloban', 'vehicular', 'example4', 'radio', '03/01/2020', NULL, '03/31/2020 12:00 AM - 04/01/2020 12:00 AM', '03/31/2020 12:00 AM - 04/01/2020 12:00 AM', '03/31/2020 12:00 AM - 04/01/2020 12:00 AM', 'kimse', '03/16/1927', 'male', 'example4', '93', 'example4', '092828288282', 'yes', NULL, 'example4', 'example4', 'Emergency Transport', 'example4', '3:45 PM', '3:45 PM', '3:45 PM', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', NULL, NULL, 'normal', 'normal', 'example4', 'example4', 'example4', 'HTN,DM', 'example4', 'example4', 'example4', '03/01/2020', '03/01/2020', '03/01/2020', 'example4', 'example4', '1', '1', '03/01/2020', '03/01/2020', '03/01/2020', NULL, 'OPA,NPA', NULL, NULL, 'example4', NULL, NULL, NULL, 'sssssss', 'None', 'None', 'None', 'None', 'None', 'None', 'example4', 'example4', 'example4', 'example4', 'example4', NULL, 'example4', NULL, 'example4', NULL, 'example4', NULL, '2020-04-02 13:59:23');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT 'deactivated',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (1, 'tan', 'tan', 'tan@gmail.com', 'tan', '1234', 'admin', 'activated', '2020-02-09 20:53:17');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (2, 'admins', 'admin', 'admin@gmail.com', 'admin', 'admin', 'admin', 'activated', '2020-04-02 14:06:17');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (3, 'staffs', 'staff', 'staff@gmail.com', 'staff', 'staff', 'staff', 'activated', '2020-03-03 11:44:06');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (4, 'asdf', 'asdf', 'asddasdasd', 'asdf', '123456', 'staff', NULL, '2020-01-18 13:04:46');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (5, 'example', 'example', 'example', 'example', 'example', 'staff', NULL, '2020-01-21 19:53:45');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (6, 'example1', 'example1', 'example1', 'example1', 'example1', 'admin', NULL, '2020-01-18 21:02:26');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (7, 'example2', 'example2', 'example2', 'example2', 'example2', 'admin', NULL, '2020-01-18 21:07:19');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (8, 'example3', 'example3', 'example3', 'example3', 'example3', 'admin', NULL, '2020-01-18 21:12:39');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (9, 'example45', 'example45', 'example45', 'example45', 'example45', 'admin', NULL, '2020-01-21 19:49:26');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (12, 'star', 'star', 'star', 'star', 'star', 'admin', NULL, '2020-02-09 14:16:05');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (13, 'batman', 'Hshsjshs', 'Hshahajan', 'batman', 'batman', 'admin', 'activated', '2020-02-09 20:58:47');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (14, 'AKIRA', 'YUKI', 'xxx.xxx@gmail.com', 'FragrantParakeet', 'MountEverest', 'staff', 'activated', '2020-02-10 16:31:16');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (15, 'try', 'try', 'try', 'try', 'try', 'admin', 'deactivated', '2020-03-04 19:08:50');
INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `role_id`, `status`, `date_created`) VALUES (16, 'try1', 'try1', 'try1', 'try1', 'try1', 'admin', 'deactivated', '2020-03-04 19:11:32');


